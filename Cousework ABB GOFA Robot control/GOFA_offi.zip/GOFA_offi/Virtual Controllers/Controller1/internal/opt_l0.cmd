
include -path "C:/Users/lenovo/AppData/Local/ABB/RobotWare/RobotControl_7.20.0/options/vnet/virtualInc_opt.cmd"

include -path "C:/Users/lenovo/AppData/Local/ABB/RobotWare/RobotControl_7.20.0/options/sc/ScInc_opt.cmd"
